## Run this first in the console

library(tidycensus)
census_api_key("[YOUR API KEY HERE")